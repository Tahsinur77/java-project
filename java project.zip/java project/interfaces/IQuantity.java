package interfaces ;

import java.lang.*;
import classes.*;


public interface IQuantity{
	void addQuantity(int amount) ;
	void sellQuantity(int amount) ;
}